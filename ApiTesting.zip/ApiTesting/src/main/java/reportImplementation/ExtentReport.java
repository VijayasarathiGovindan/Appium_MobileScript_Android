package reportImplementation;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReport {

    public static ExtentReports extent;
    public static ExtentTest test;

    public static void startReport(String outfileName, String xmlLocation) {
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(outfileName);
        htmlReporter.loadConfig(xmlLocation);
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
    }

    public static void createTest(String testName) {

        test = extent.createTest(testName);
    }

    public static void stepStatus(String desc, String status) {
       // String screenshotImage = "<img data-featherlight='" + runtimescnshtpath + "' class='step-img' src='" + runtimescnshtpath + "' data-src='" + runtimescnshtpath + "'/>";
        switch (status) {

            case "pass":
                test.pass(desc);
                break;
            case "fail":
                test.fail(desc);
                break;
            case "skip":
                test.skip(desc);
                break;
            case "info":
                test.info(desc);
                break;

        }
    }

    public static void flushReport() {
        extent.flush();
    }

}