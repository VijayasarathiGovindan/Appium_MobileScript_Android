package dto;

import lombok.Data;

@Data
public class ResponseDto {

        public String id;

        public String firstName;
        public String lastName;
        public String email;
        public Address address;
        @Data
        public static class Address{
                public String street;
                public String city;
        }
}
