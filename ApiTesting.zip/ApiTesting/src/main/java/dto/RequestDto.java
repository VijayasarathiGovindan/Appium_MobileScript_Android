package dto;

import lombok.Data;

@Data
public class RequestDto {

        public String firstName;
        public String lastName;
        public String email;
        public Address address;
        @Data
        public static class Address{
               public String street;
               public String city;
        }

}
