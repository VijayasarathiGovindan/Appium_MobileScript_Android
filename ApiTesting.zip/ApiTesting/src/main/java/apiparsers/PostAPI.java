package apiparsers;

import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import dto.RequestDto;
import org.junit.Test;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class PostAPI {

    @Test
    public void testAPI() {

        Gson gson = new Gson();

        try {
            HttpResponse<String> response = Unirest.post("http://localhost:9009/save")
                    .header("content-type", "application/json")
                    .body("{\n" +
                            "\t\"firstName\" : \"Shashitest\",\n" +
                            "\t\"lastName\" : \"Own\",\n" +
                            "\t\"email\" : \"shashitest@test.com\",\n" +
                            "\t\"address\" : {\n" +
                            "\t\t\"street\" : \"Sholinganallor\",\n" +
                            "\t\t\"city\" : \"Chennai\"\n" +
                            "\t}\n" +
                            "}")
                    .asString();


            System.out.println(gson.toJson(response));
        } catch (UnirestException e) {
            e.printStackTrace();
        }

    }
/*

 @Test
    public void executeAPI() throws FileNotFoundException {

        Gson gson = new Gson();

        RequestDto requestDto = gson.fromJson(new FileReader("./src/main/resources/apiRequest.json"), RequestDto.class);
        URL url;
        String baseUrl ="https://hcl-vijay.au.auth0.com/oauth/token";
        HttpURLConnection restConnection = null;

        try {
            url = new URL(baseUrl);
            restConnection = (HttpURLConnection)url.openConnection();
            restConnection.setRequestMethod("POST");
            restConnection.setRequestProperty("Content-Type","application/json");
           // restConnection.setRequestProperty("Accept", "application/vnd.api+json");

            restConnection.setUseCaches(false);
            restConnection.setDoInput(true);
            restConnection.setDoOutput(true);

            restConnection.getResponseCode();
            restConnection.getResponseMessage();

            DataOutputStream wr = new DataOutputStream (restConnection.getOutputStream ());
            wr.writeBytes (gson.toJson(requestDto));
            wr.flush ();
            wr.close ();

            InputStream is = restConnection.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
            String line;
            StringBuffer response = new StringBuffer();
            while((line = rd.readLine()) != null) {
                response.append(line);
                response.append('\r');
            }

            rd.close();

            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("./src/test/resources/jsonResponses/"+"-"+"_Res.json"));

            bufferedWriter.write(String.valueOf(response));
            bufferedWriter.close();

        }catch (Exception e){
            System.out.println(e);
        }



    }
*/

}
