package featureImplementation;

import cucumber.api.Scenario;
import cucumber.api.java.*;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.lang.reflect.Array;
import java.util.Collection;

import static reportImplementation.ExtentReport.*;

public class RestAPIStories {

    @Before
    public void beforeSetup(Scenario scenario) {
        startReport("./src/main/resources/OutFile.html", "./src/main/resources/extentConfig.xml");

        String testDesc = scenario.getName();
        createTest(testDesc);

    }

    @After
    public void flush(){
        flushReport();
    }

    @Given("I Entered user information 'firstName' and 'lastName' and 'email'")
    public void given() {

        System.out.println("Given Story success");
        stepStatus("Input data added to JSon", "Pass");

    }

    @When("I Added service 'URL' with 'headers'")
    public void when() {

        System.out.println("When Story success");
        stepStatus("Got URL and Added Headers", "Pass");

    }

    @Then("I Posted user info to end-point")
    public void then() {
        System.out.println("Then Story success");
        stepStatus("Data Posted Successfully", "Pass");

    }

    @And("I Verified service response with 'email'")
    public void andThen() {

        System.out.println("And Story success");
        stepStatus("Response got successflly verified", "Pass");

    }
}
